
exports.handler = async (event) => {
  // Get a random sweet potato fact
 const randomFact = potatolessFacts[Math.floor(Math.random() * potatolessFacts.length)];

 // Prepare the response
 const response = {
   statusCode: 200,
   body: randomFact,
 };

 return response;
};

const potatolessFacts = [
   "Sweet potatoes are a great source of vitamin A, which is important for vision health.",
   "There are over 400 varieties of sweet potatoes around the world.",
   "Sweet potatoes are not related to regular potatoes; they belong to the morning glory family.",
   "Sweet potatoes are high in fiber, making them good for digestion.",
   "Sweet potatoes come in different colors, including orange, purple, and white.",
   "Sweet potatoes are one of the oldest vegetables known to man.",
   "North Carolina is the largest producer of sweet potatoes in the United States.",
   "Sweet potatoes are often used in Thanksgiving dishes like casseroles and pies.",
   "Sweet potatoes and yams are not the same vegetable even though many Americans use the two names interchangeably.",
 ];